/** Automatically generated file. DO NOT MODIFY */
package br.org.esperemenos;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}